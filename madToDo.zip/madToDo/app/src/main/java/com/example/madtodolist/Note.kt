package com.example.madtodolist

data class Note(val id: Int,val title: String,val content: String)
